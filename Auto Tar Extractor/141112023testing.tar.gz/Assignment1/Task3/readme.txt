
path="$PWD/for_loop_same_line_output.sh"
bash $path
