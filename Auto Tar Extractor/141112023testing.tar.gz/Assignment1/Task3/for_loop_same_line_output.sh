echo "Program to print 1 to 9 using for loop in same line"
for a in 0 1 2 3 4 5 6 7 8 9
do
echo -n $a
echo -n " "
done
