echo "This script is just to show that a program can be executed without changing permission explicitly by: . script_name"
