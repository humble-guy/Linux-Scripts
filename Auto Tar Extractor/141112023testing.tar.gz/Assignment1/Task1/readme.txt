#Instructions to run the program

#Run the script
path="$PWD/a.sh"
bash $path

#Here, no permission is needed by using the above #commands.
