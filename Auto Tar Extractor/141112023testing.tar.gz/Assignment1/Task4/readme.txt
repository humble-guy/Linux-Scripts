path="$PWD/for_loop_in_range.sh"
bash $path
