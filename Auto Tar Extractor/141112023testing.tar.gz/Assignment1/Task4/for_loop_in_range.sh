echo "Script to print 0 to 10 with increment of 2 "
for i in {0..10..2}
do
echo $i
done
